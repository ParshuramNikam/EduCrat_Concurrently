import React, { useContext } from 'react'
import AppUserContext from '../../context/AppUserContext'
import DefaultNavbar from './defaultNavbar/DefaultNavbar'
import TutorNavbar from './tutorNavbar/TutorNavbar'

const Navbar = ({ navbarType, isTutor, homepage }) => {
    const { appUser } = useContext(AppUserContext);
    
    if (navbarType) {
        if (navbarType === "default") return <DefaultNavbar homepage={homepage} isTutor={isTutor} />
        if (navbarType === "home") return <DefaultNavbar homepage={homepage} isTutor={isTutor} />
        if (navbarType === "dashboard") return <DefaultNavbar homepage={homepage} isTutor={isTutor} />
        if (navbarType === "tutor_dashboard") return <TutorNavbar />
    } else {
        return (
            <div>NOT A VALID NAVBAR</div>
        )
    }
}

export default Navbar