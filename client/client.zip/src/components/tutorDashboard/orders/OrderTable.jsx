import axios from "axios";
import React, { useContext, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import AppUserContext from "../../../context/AppUserContext";
import { backendURL } from "../../../data/vars";
import "./OrderTable.css";

const OrderTable = () => {
  const { appUser } = useContext(AppUserContext);

  const [orders, setOrders] = useState([]);

  useEffect(() => {
    if (appUser?._id) {
      axios
        .get(backendURL + "/api/orders/tutor/" + appUser._id)
        .then((res) => {
          console.log(res.data);
          setOrders(res.data);
        })
        .catch((err) => {
          console.log(err);
        });
    }
  }, [appUser]);

  return (
    <div className="order_table_container">
      <div className="responsive-table" style={{ overflowX: "scroll" }}>
        <table className="order_table">
          <thead>
            <th>
              <span className="gig_thead_th-1">BUYER</span>
            </th>
            <th>
              <span className="gig_thead_th-2">GIG</span>
            </th>
            {/* <th className="due-head">DUE ON</th> */}
            <th className="total-head">TOTAL</th>
            {/* <th className="status-head">STATUS</th> */}
          </thead>

          <tbody>
            {orders?.gigBuyers?.map((order) => {
              return (
                <tr>
                  <td className="order_table_avatar_wrapper">
                    {/* <div className="order_table_student_avatar">
                        <img width={30} height={30} src="https://images.unsplash.com/photo-1527980965255-d3b416303d12?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=580&q=80" alt="" />
                      </div> */}
                    <Link to={"/profile/" + order?.student_id?._id}>
                      <div className="order_table_student_name">
                        {order?.student_id?.username}
                      </div>
                    </Link>
                  </td>
                  <td className="order_table_gig_title">
                    <Link to={"/tutor-gig/" + order?.gig_id?._id}>
                      <div>
                        {order?.gig_id?.title
                          ? order.gig_id.title.slice(0, 40)
                          : "NA"}{" "}
                        {order?.gig_id?.title.length > 40 && "..."}
                      </div>
                    </Link>
                  </td>
                  <td className="order_table_price">
                    $
                    {order?.gig_id?.pricing?.actualPrice
                      ? order?.gig_id?.pricing?.actualPrice
                      : order?.gigPrice}
                  </td>
                  {/* <td className="">
                      <button className="order_table_status_btn">{order.status}</button>
                    </td> */}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default OrderTable;
