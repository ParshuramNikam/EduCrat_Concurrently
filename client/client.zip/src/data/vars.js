const backendURL = "http://localhost:8000";
const frontendURL = "http://localhost:3000";

module.exports = { frontendURL, backendURL }; 