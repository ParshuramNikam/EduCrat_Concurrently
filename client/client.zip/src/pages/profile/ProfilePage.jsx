import React, { useContext, useEffect, useState } from "react";
import UserDetails from "../../components/profile/leftSide/userProfile/userDescription/UserDescription";
import UserProfileDetails from "../../components/profile/leftSide/userProfile/userProfileDetails/UserProfileDetails";
import NewGig from "../../components/profile/rightSide/addNewGig/NewGig";
import ProfileGig from "../../components/profile/rightSide/profileGig/ProfileGig";
import "./ProfilePage.css";
import { backendURL } from "../../data/vars";
import AppUserContext from "../../context/AppUserContext";
import axios from "axios";
import {
  Link,
  useNavigate,
  useParams,
  useSearchParams,
} from "react-router-dom";

const ProfilePage = ({ type }) => {
  const { appUser } = useContext(AppUserContext);
  const [userData, setUserData] = useState("");
  const [paramsUser, setParamsUser] = useState("");
  const { id } = useParams();
  const navigate = useNavigate();

  const [isSelf, setIsSelf] = useState(false);
  const [deletedItem, setDeletedItem] = useState(0);

  useEffect(() => {
    if (appUser) {
      axios
        .get(backendURL + "/api/user/" + appUser._id)
        .then((res) => {
          console.log(res.data.user);
          setUserData(res.data.user);
        })
        .catch((err) => console.log(err));
    }
  }, [appUser]);

  useEffect(() => {
    if (id) {
      axios
        .get(backendURL + "/api/user/" + id)
        .then((res) => {
          if (!res.data.user) {
            return alert("User not found");
          }
          console.log(res.data.user);
          setParamsUser(res.data.user);
          if (res.data.user._id === appUser._id) {
            setIsSelf(true);
          }
        })
        .catch((error) => {
          if (error.response.status === 500) {
            alert("User not found!");
          } else {
            console.log(error.message);
          }
        })
        .finally(() => {
          // navigate('/');
        });
    } else {
      navigate("/dashboard");
    }
  }, [id, deletedItem]);

  return (
    <div className="profile_page">
      <div className="dashboard_container page_container">
        <div className="left_side">
          <UserProfileDetails paramsUser={paramsUser} userData={userData} />
          <UserDetails paramsUser={paramsUser} userData={userData} />
        </div>
        <div className="right-side-container">
          <div className="right_side">
            {paramsUser?.gigsInfo && paramsUser.gigsInfo.length > 0 ? (
              <div className="gig_title">All Gigs:</div>
            ) : (
              <div className="gig_title">No gigs Available</div>
            )}
            <div className="gig_container">
              {appUser?._id === paramsUser?._id && appUser?.role === 1 && <NewGig />}
              {paramsUser &&
                paramsUser.gigsInfo.map((gig, index) => (
                  <Link to={"/tutor-gig/" + gig._id}>
                    <ProfileGig
                      deletedItem={deletedItem}
                      setDeletedItem={setDeletedItem}
                      paramsUser={paramsUser}
                      userData={userData}
                      key={index}
                      gigDetails={gig}
                    />
                  </Link>
                ))}
              {/* {
                userData && userData.gigsInfo && userData.gigsInfo.length === 0 && <div className="gig_title">No Gigs Available</div>
              } */}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;
