import React from "react";
import ProfileProgressWrapper from "../../components/tutorDashboard/leftSide/profileProgressWrapper/ProfileProgressWrapper";
import OrderStatus from "../../components/tutorDashboard/rightSide/orderStatus/OrderStatus";
import "./TutorDashboard.css";
import DashboardGig from "../../components/tutorDashboard/rightSide/dashboardGig/DashboardGig";
import CreateNewGig from "../../components/createNewGig/CreateNewGig";

const TutorDashboard = () => {
  return (
    <div className="tutor_dashboard_page">
      <div className="dashboard_container page_container">
        <div className="left_side">
          <ProfileProgressWrapper />
        </div>

        <div className="right_side">
          <OrderStatus />
          <div className="gig_title">
            <div className="gig_heading">Your Gigs:</div>
            <div className="gig_create_new">
              {" "}
              <CreateNewGig />
            </div>
          </div>
          <div className="dashboard-gig-wrapper">
            <div className="dashboard-gig-container">
              <DashboardGig />
              <DashboardGig />
              <DashboardGig />
              <DashboardGig />
              <DashboardGig />
              <DashboardGig />
            </div>
            <div className="extra-spacing"></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TutorDashboard;
